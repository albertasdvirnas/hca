Add to path and then
Edit and run mp_generation

Uses STOMP algorithm+ HCA-type stuff

Dau HA, Keogh E. Matrix profile V: A generic technique to incorporate domain knowledge into motif discovery. InProceedings of the 23rd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining 2017 Aug 4 (pp. 125-134).